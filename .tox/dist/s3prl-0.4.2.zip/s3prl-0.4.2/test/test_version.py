import s3prl


def test_version():
    s3prl.__version__
