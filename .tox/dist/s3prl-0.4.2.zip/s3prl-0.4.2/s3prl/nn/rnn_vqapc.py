from s3prl.nn.rnn_apc import ApcModel as VqApcModel
