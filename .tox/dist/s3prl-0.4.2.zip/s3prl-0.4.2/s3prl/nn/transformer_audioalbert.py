from s3prl.nn.transformer_mockingjay import (
    TransformerConfig,
    TransformerModel,
    TransformerSpecPredictionHead,
)
